We don't use cargo build script, since this data will be changed rarely and
there is no point in regenerating it each time.

To regenerate files run:

```
cargo run
```
