We don't use cargo build script, since this data will rarely be changed and
there is no point in regenerating it each time.

To regenerate files run:

```
cargo run
```
